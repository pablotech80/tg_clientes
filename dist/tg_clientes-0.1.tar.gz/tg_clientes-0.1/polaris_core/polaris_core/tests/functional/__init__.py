# -*- coding: utf-8 -*-
"""Functional test suite for the controllers of the application."""

# -*- coding: utf-8 -*-
"""The polaris-core package"""
